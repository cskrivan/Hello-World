﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.Specialized;

namespace HelloWorldCJS
{
    class SingletonHW
    {
        private static SingletonHW instance = null;
        private string message { get; set; }
        private SingletonHW()
        {
            message = ConfigurationManager.AppSettings.Get("message");
        }
        private static object thisLock = new object();
    public static SingletonHW Instance
        {
        get
            {
                lock(thisLock)
                {
                    if (SingletonHW.instance == null)
                    SingletonHW.instance = new SingletonHW();

                    return SingletonHW.instance;
                }
            }
        }
    public void ShowMessage()
    {
        Console.WriteLine(message);
    }

    }


}
